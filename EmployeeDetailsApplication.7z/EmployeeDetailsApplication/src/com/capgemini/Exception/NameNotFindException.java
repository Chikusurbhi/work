package com.capgemini.Exception;

public class NameNotFindException extends Exception {

}
