package com.cg.sample.dao;

import java.util.HashMap;

import com.cg.sample.bean.Trainer;

public interface FeedbackDAO 
{
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();

}
