 package com.cg.service;

import java.util.List;

import com.cg.beans.Address;
import com.cg.beans.Employee;

public interface EmployeeService {
	Employee createEmployee(String name,Address address);
	List<Employee>SearchByName(String name);

}
