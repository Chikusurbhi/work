package com.cg.service;

import java.util.List;

import com.cg.beans.Address;
import com.cg.beans.Employee;
import com.cg.dao.employeedaoimpl;

public class Employeeserviceimpl implements EmployeeService {
	
	
	
	
	employeedaoimpl daoimp= new employeedaoimpl();
	
	Employeeserviceimpl ser;
	
	 @Override
	public Employee createEmployee(String name, Address address) 
	{
		Employee e= new Employee(name, address);
				daoimp.Save(e);
		 return e;
		
		// TODO Auto-generated method stub
	}
	

	@Override
	public List<Employee> SearchByName(String name) {
		
		
		 List<Employee> em= daoimp.findByName(name);
		 return em;
		// TODO Auto-generated method stub
		
	}

}
