package com.cg.main;

import java.util.List;
import java.util.Scanner;


import com.cg.beans.Address;
import com.cg.beans.City;
import com.cg.beans.Country;
import com.cg.beans.Employee;
import com.cg.service.Employeeserviceimpl;

public class main {
	
	
	public static void main(String[] args)
	{
		
		 Employeeserviceimpl ser= new Employeeserviceimpl();
		
		Scanner sc= new Scanner(System.in);
		System.out.println("1:For creating  employee information");
		System.out.println("2:for displaying with the help of name");
		System.out.println("3:exit");
		int k = sc.nextInt();
		switch(k)
		
		{
		case 1:
		{
			
			City l= new City("sitapur");
			Country con5 = new Country("India",l);
			Address add5= new Address("lmpd",con5);
			Employee empj= new Employee("priya",add5);
			 empj=ser.createEmployee(empj.getName(), empj.getAddress());
			 System.out.println("New Customer is created"+empj);
			 break;
			   }
		case 2:
		{
			List <Employee> empp = ser.SearchByName("priya");
			
			
				System.out.println(empp);

		
		}
		case 3:
		{
			System.exit(0);
		}
		
		
		
		
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
