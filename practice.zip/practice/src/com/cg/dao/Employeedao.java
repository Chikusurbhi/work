package com.cg.dao;

import java.util.List;

import com.cg.beans.Employee;

public interface Employeedao {
	Employee Save(Employee e);
	List <Employee>findByName (String name);

}
