package com.cg.dao;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.cg.beans.Address;
import com.cg.beans.City;
import com.cg.beans.Country;
import com.cg.beans.Employee;

public class employeedaoimpl  implements Employeedao {
	
	Map<Integer ,Employee> nmap;
	public employeedaoimpl()
	{
		nmap= new HashMap<Integer,Employee>();
		
		City c= new City("Pune");
		Country con = new Country("India",c);
		Address add= new Address("lmp",con);
		Employee emp= new Employee("priya",add);
		nmap.put(emp.getId(), emp);
		
		
		
		City c1= new City("lucknow");
		Country con1 = new Country("India",c1);
		Address add1= new Address("lmpk",con1);
		Employee emp1= new Employee("priyanka",add1);
		nmap.put(emp1.getId(), emp1);
		
		
		
		
		City c2= new City("kanpur");
		Country con2 = new Country("India",c2);
		Address add2= new Address("lmph",con2);
		Employee emp2= new Employee("priyam",add2);
		nmap.put(emp2.getId(), emp2);
		
		
		
		
		City c3= new City("varanasi");
		Country con3 = new Country("India",c3);
		Address add3= new Address("lmps",con3);
		Employee emp3= new Employee("priya",add3);
		nmap.put(emp3.getId(), emp3);
		
		
		
		
	}
	
	@Override
	public Employee Save(Employee e) {
		
	return 	nmap.putIfAbsent(e.getId(), e);
		
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Employee> findByName(String name) {
		List<Employee> e= new LinkedList<Employee>();
		for(Map.Entry<Integer, Employee> emp: nmap.entrySet())
		{
			if(emp.getValue().getName().equals(name))
				e.add(emp.getValue());
			
		}
		
		return e;
		
}
}
