package com.cg.beans;

public class Address {
	
	String addressline;
	Country country;
	public Address(String addressline, Country country) {
	
		this.addressline = addressline;
		this.country = country;
	}
	public String getAddressline() {
		return addressline;
	}
	public void setAddressline(String addressline) {
		this.addressline = addressline;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	@Override
	public String toString() {
		return "Address [addressline=" + addressline + ", country=" + country + "]";
	}
	

}
