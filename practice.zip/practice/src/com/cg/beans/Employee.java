package com.cg.beans;

public class Employee {
	
	
	String name;
	Address address;
	int id;
	public Employee(String name, Address address) {
	
		this.name = name;
		this.address = address;
		this.id = (int)(Math.random()*100);
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", address=" + address + ", id=" + id + "]";
	}
	
	

}
