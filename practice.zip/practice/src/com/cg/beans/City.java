package com.cg.beans;

public class City {
	String name;

	public City(String name)
	{
	
		this.name = name;
		
	}
	public City()
	{
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
