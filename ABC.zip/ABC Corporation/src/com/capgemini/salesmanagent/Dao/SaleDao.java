package com.capgemini.salesmanagent.Dao;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;
import com.capgemini.salesmanagment.util.CollectionUtil;

public class SaleDao implements ISaleDao {
	private static HashMap<Integer, Sale> sales;
	 public SaleDao()
	 {
		 sales=CollectionUtil.getCollection();
		 LocalDate d=LocalDate.now();
		 Sale s= new Sale(1001, "Smartphone", "Electronics", d, 0, 0);
		 sales.put(s.getSaleId(), s);
		 
		 LocalDate d1=LocalDate.now();
		 Sale s1= new Sale(1001, "Smartphone", "Electronics", d, 0, 0);
		 sales.put(s1.getSaleId(), s1);
		 
		 
		 
		 LocalDate d2=LocalDate.now();
		 Sale s2= new Sale(1001, "Iphone", "Electronics", d2, 0, 0);
		 sales.put(s2.getSaleId(), s2);
		 
		 
		 
		 LocalDate d3=LocalDate.now();
		 Sale s3= new Sale(1001, "Smartphone", "Electronics", d3, 0, 0);
		 sales.put(s3.getSaleId(), s3);
		 
		 LocalDate d4=LocalDate.now();
		 Sale s4= new Sale(1001, "Smartphone", "Electronics", d4, 0, 0);
		 sales.put(s4.getSaleId(), s4);
		
		 
		 
		 
		 

	 }
	 public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		
		
		sales.putIfAbsent(sale.getSaleId(), sale);
		
		
		return sales;
	}

}
