package com.capgemini.salesmanagment.bean;

import java.time.LocalDate;

public class Sale {
	
	private int SaleId;
	private int prodCode;
	
	private String productName;
	private String Category;
	private LocalDate SaleDate;
	private int quantity ;
	private float lineTotal;
	 static int c;
	
	public Sale()
	{
		
	}
	public Sale( int prodCode, String productName, String category, LocalDate saleDate, int quantity,
			float lineTotal) {
		super();
		c=(int)  (Math.random() * 10000);
		c = SaleId;
		this.prodCode = prodCode;
		this.productName = productName;
		this.Category = category;
		this.SaleDate = saleDate;
		this.quantity = quantity;
		this.lineTotal = lineTotal;
	}
	public int getSaleId() {
		return SaleId;
	}
	public void setSaleId(int saleId) {
		SaleId = saleId;
	}
	public int getProdCode() {
		return prodCode;
	}
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public LocalDate getSaleDate() {
		return SaleDate;
	}
	public void setSaleDate(LocalDate saleDate) {
		SaleDate = saleDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public float getLineTotal() {
		return lineTotal;
	}
	public void setLineTotal(float lineTotal) {
		this.lineTotal = lineTotal;
	}
	@Override
	public String toString() {
		return "Sale [SaleId=" + SaleId + ", prodCode=" + prodCode + ", productName=" + productName + ", Category="
				+ Category + ", SaleDate=" + SaleDate + ", quantity=" + quantity + ", lineTotal=" + lineTotal + "]";
	}
	
	
	
	
	
	
	
	

}
