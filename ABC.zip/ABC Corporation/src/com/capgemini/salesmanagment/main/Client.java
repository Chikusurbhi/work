package com.capgemini.salesmanagment.main;

import java.util.Scanner;

import com.capgemini.salesmanagment.service.ISaleService;
import com.capgemini.salesmanagment.service.SaleService;

public class Client {
	private static Scanner sc;
	ISaleService Serviceref = new SaleService();
	
	public static void main (String args[])
	{
		sc= new Scanner(System.in);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
