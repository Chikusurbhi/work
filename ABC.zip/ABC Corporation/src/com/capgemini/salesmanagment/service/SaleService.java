package com.capgemini.salesmanagment.service;

import java.util.HashMap;

import com.capgemini.salesmanagent.Dao.ISaleDao;
import com.capgemini.salesmanagent.Dao.SaleDao;
import com.capgemini.salesmanagment.bean.Sale;

public class SaleService implements ISaleService
{
	
ISaleDao serviceref = new SaleDao();


	
	@Override
	public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
	
		return serviceref.insertSaleDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) {
		if(productId ==1001||productId == 1002||productId ==1003||productId ==1004)
			return true;
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateQuantity(int qty) {
		if(qty<0)
			return true;
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean ValidateProductCat(String prodCat) {
		
		if(prodCat.equals ("Electronics" )|| prodCat.equals("Toys"))
			return true;
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean VAlidateProductName(String prodName) {
		
		
		if(prodName.equals("TV")||prodName.equals("Smart Phone")||prodName.equals("Video Games")||prodName.equals("Soft toy ")||prodName.equals("Telescope")||prodName.equals("Barabee Doll"))
		
		return true;
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean VAlidateProductPrice(float price) {
		
	if(price>200)
		return true;
		
		return false;
	}

}
