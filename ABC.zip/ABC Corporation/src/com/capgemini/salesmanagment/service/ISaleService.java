package com.capgemini.salesmanagment.service;

import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;

public interface ISaleService {
	public HashMap<Integer,Sale> insertSaleDetails(Sale sale);
	
	public boolean validateProductCode(int productId);
	boolean validateQuantity(int qty);
	public boolean ValidateProductCat(String prodCat);
	public boolean VAlidateProductName(String prodName);
	public boolean VAlidateProductPrice(float price);
	
	
	
	
	

}
