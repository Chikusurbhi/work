package com.capgemini.salesmanagent.Dao;

import java.time.LocalDate;
import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;
import com.capgemini.salesmanagment.util.CollectionUtil;

public class SaleDao implements ISaleDao {
	private static HashMap<Integer, Sale> sales;
	 public SaleDao()
	 {
		 sales=CollectionUtil.getCollection();
		
		/* LocalDate d=LocalDate.now();
		 Sale s= new Sale(1001, "Smartphone", "Electronics", d, 0, 0);
		 sales.put(s.getSaleId(), s);
		
		 */
		 
		 

	 }
	 public HashMap<Integer, Sale> insertSaleDetails(Sale sale) {
		
		
		sales.putIfAbsent(sale.getSaleId(), sale);
		
		
		return sales;
	}

}
