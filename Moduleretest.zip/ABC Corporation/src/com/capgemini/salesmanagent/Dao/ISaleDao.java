package com.capgemini.salesmanagent.Dao;

import java.util.HashMap;

import com.capgemini.salesmanagment.bean.Sale;

public interface ISaleDao {
	
	public HashMap<Integer , Sale> insertSaleDetails(Sale sale);

}
