package com.capgemini.salesmanagment.main;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.salesmanagment.Exception.PriceNotFoundException;
import com.capgemini.salesmanagment.Exception.ProductCategoryNotfoundexception;
import com.capgemini.salesmanagment.Exception.ProductCodeNotFoundException;
import com.capgemini.salesmanagment.Exception.ProductNameNotFoundException;
import com.capgemini.salesmanagment.Exception.QuantityNotFoundexception;
import com.capgemini.salesmanagment.bean.Sale;
import com.capgemini.salesmanagment.service.ISaleService;
import com.capgemini.salesmanagment.service.SaleService;

public class Client {
	
	
	
	public static void main (String args[]) throws ProductCodeNotFoundException, QuantityNotFoundexception, ProductCategoryNotfoundexception, ProductNameNotFoundException, PriceNotFoundException
	{
		ISaleService service = new SaleService();
		Scanner sc= new Scanner(System.in);
		
		System.out.println("1:Enter the Product code");
		int a = sc.nextInt();
		if(service.validateProductCode(a)==false)
		
		{
			
			throw new ProductCodeNotFoundException();
			}
		
		
		
		System.out.println("2:Enter the quantity  ");
		sc.nextLine();
		int b= sc.nextInt();
		
		if(service.validateQuantity(b)== false)
		{
			System.out.println("The quantity should be less than 5 and more then 0");
			throw new QuantityNotFoundexception();
		}
		
	
		System.out.println("3:Enter the Product category ");
		String  c= sc.next();
		if(service.ValidateProductCat(c)== false)
		{
			System.out.println("The quantity should be between Electronics and Toys");
			throw new ProductCategoryNotfoundexception();
		}
		System.out.println("4:Enter the Product Name  ");
		String d= sc.next();
		if(service.VAlidateProductName(d)==false)
		{
			System.out.println("The product Name should be TV or SmartPhone or VideGames or Softtoy or Telescope or BarbeeDoll");
			throw new ProductNameNotFoundException();
		}		
		System.out.println("6:Enter the Product Price   ");
		int f= sc.nextInt();
		if(service.VAlidateProductPrice(f)==false)
		{
			System.out.println("The Product Price should be greater than 200");
			throw new PriceNotFoundException();
		}
		
		 Sale sale1= new Sale();
		 
		 sale1.setCategory(c);
		 sale1.setProdCode(a);
		 sale1.setProductName(d);
		 sale1.setQuantity(b);
		 sale1.setLineTotal(b*f);
          int tqty=0;float tltl=0;
		
		 HashMap<Integer, Sale> sale2=service.insertSaleDetails(sale1);
		 
		 
		 for(Map.Entry<Integer, Sale> var: sale2.entrySet())
		 {
			 System.out.println("in");
			 tqty=tqty+var.getValue().getQuantity();
			 tltl=tltl+var.getValue().getLineTotal();
			 System.out.println(var.getValue().getLineTotal());
			System.out.println(var.getValue().getProdCode());
			System.out.println(var.getValue().getProductName());
			
	 	 }
		 
		 System.out.println("Quantity:"+tqty);
		 System.out.println("Line Total:"+tltl);
		 
		 	
		
		
	}

}
