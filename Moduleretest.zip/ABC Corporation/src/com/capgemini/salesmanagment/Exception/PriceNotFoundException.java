package com.capgemini.salesmanagment.Exception;

public class PriceNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
