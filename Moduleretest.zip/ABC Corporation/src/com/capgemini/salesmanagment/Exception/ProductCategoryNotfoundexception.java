package com.capgemini.salesmanagment.Exception;

public class ProductCategoryNotfoundexception extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
