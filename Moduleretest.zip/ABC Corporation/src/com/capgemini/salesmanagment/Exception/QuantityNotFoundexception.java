package com.capgemini.salesmanagment.Exception;

public class QuantityNotFoundexception extends Exception  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
