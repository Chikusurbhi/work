package com.capgemini.salesmanagment.Exception;

public class ProductCodeNotFoundException extends Exception  {

}
