package com.capgemini.salesmanagment.Exception;

public class ProductNameNotFoundException  extends Exception  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
