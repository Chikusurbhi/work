package com.service;

import java.util.HashMap;

import com.beans.Trainer;

public interface IFeedbackService {
	
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();

}
