package com.service;

import java.util.HashMap;

import com.beans.Trainer;
import com.dao.FeedbackDaoImpl;

public class FeedbackServiceImpl  implements IFeedbackService {
	FeedbackDaoImpl daoimpl= new FeedbackDaoImpl();
	

	@Override
	public void addFeedback(Trainer trainer) {
	daoimpl.addFeedback(trainer);
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Integer, Trainer> getTrainerList() {
		
		 return daoimpl.getTrainerList();
		// TODO Auto-generated method stub
		
	}

}
