package com.dao;

import java.util.HashMap;

import com.beans.Trainer;

public interface IFeedbackDao {
	
	
	
	
	public void addFeedback(Trainer trainer);
	public HashMap<Integer,Trainer> getTrainerList();

}
