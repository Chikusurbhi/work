package com.dao;

import java.util.HashMap;


import java.util.Map;

import com.beans.Trainer;
import com.cg.Util.dbUtil;

public class FeedbackDaoImpl implements IFeedbackDao {
	
	
	Map<Integer , Trainer > nmap;
	public FeedbackDaoImpl() {
		
		
		nmap= dbUtil.getFeedbackList();
		
		
		
		
	}
	
	
	
	@Override
	public void addFeedback(Trainer trainer) {
		int a = (int) (Math.random()*1000);
		
	nmap.putIfAbsent(a, trainer);
	
	
		
		
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public HashMap<Integer,Trainer> getTrainerList() {
		
		
		
		return (HashMap<Integer, Trainer>) nmap;
		
		// TODO Auto-generated method stub
		
	}

}
