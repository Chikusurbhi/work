package com.cg.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.dao.AccountDAOImpl;
import com.dao.FeedbackDaoImpl;
import com.dao.IFeedbackDao;

public class TrainerTest {

	private IFeedbackDao daoref;

	
	public void before()
	{
		System.out.println("creating up dao object");
		daoref = new FeedbackDaoImpl();
	}
	
	@Test
	public void test() {
		
		
		
		
		fail("Not yet implemented");
	}

}
