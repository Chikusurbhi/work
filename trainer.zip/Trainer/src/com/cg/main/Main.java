package com.cg.main;

import java.util.Map;
import java.util.Scanner;

import com.beans.Trainer;
import com.cg.Exception.FeedbackRatingException;
import com.service.FeedbackServiceImpl;

public class Main {
	public static void main(String[] args) throws FeedbackRatingException
	{
		FeedbackServiceImpl service= new FeedbackServiceImpl();
		Scanner sc= new Scanner(System.in);
		
	
		System.out.println("1:Accept the trainer detail from use");
		System.out.println("2:Display the details of trainer where feedback rating is acceted from user ");
		System.out.println("3:Exit");
		
		
		
		int a = sc.nextInt();
		switch(a)
		{
		case 1:
		{
			System.out.println("Enter the trainer name");
			String b= sc.next();
			System.out.println("Enter the course name");
			String k= sc.next();
			System.out.println("enter the StartDate");
			String c= sc.next();
			System.out.println("Enter the endDate");
			String l= sc.next();
			System.out.println("Enter the feedback rating score");
			int m= sc.nextInt();
			
			Trainer trainer1= new Trainer(b,k,c,l,m);
			service.addFeedback(trainer1);
			
			
			 Map<Integer,Trainer> trainer2= service.getTrainerList();
			 
		
			for(Map.Entry<Integer, Trainer> var: trainer2.entrySet())
			{
			System.out.println(var.getValue().getName());
			System.out.println(var.getValue().getCourseName());
			System.out.println(var.getValue().getStartDate());
			System.out.println(var.getValue().getEndDate());
	        System.out.println(var.getValue().getRating());
				
				
				
			}
			break;
			
		}
		
		
		case 2:
		{
			int flag=0;
			System.out.println("enter the feedback rating ");
			int k = sc.nextInt();
			 Map<Integer,Trainer> trainer2=service.getTrainerList();

				for(Map.Entry<Integer, Trainer> var: trainer2.entrySet())
				{
					if(k==var.getValue().getRating()) {
				System.out.println(var.getValue().getName());
				System.out.println(var.getValue().getCourseName());
				System.out.println(var.getValue().getStartDate());
				System.out.println(var.getValue().getEndDate());
		        System.out.println(var.getValue().getRating());
					flag=1;
					}
				
					
				}
				if(flag==0)
				{
					throw new  FeedbackRatingException();
				}
			break;
			
		}
			
		case 3:
		{
			System.exit(0);
		}
			
	}
	}
}

	
	


