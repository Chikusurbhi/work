import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import com.capgemini.beans.Account;
import com.capgemini.dao.AccounDAO;
import com.capgemini.dao.AccountDAOImpl;

import Exception.IdNotFoundException;

public class TestAccountDAOOperation {
	private AccounDAO daoRef;
	@Before
	public void setup()
	{System.out.println("Setting up dao object");
	daoRef = new AccountDAOImpl();
	
	}
	
		
	@Test
	   public void test2() {
		//fail("Not yet implemented");
	   List<Account>  accounts = daoRef.findAll();
       return;
		
	}
	@Test
public void test()
{
	Account newAccount= new Account();
	newAccount.setId(5);
	newAccount.setName("rohan");
	newAccount.setBalance(50000);
boolean flag= daoRef.create(newAccount);//System.out.println(flag);
Account  newAccount1= new Account();
newAccount1.setId(5);
newAccount1.setName("Suresh");
newAccount1.setBalance(40000);
boolean flag1= daoRef.create(newAccount1);
assertFalse(flag1);

	}
	@Test
	public void test4()
	{
	    boolean a=daoRef.update(2);
		System.out.println("flag="+a);
		assertTrue(a);
	}
	
	@Test
	public void test5() throws IdNotFoundException 
	{
		Account a=daoRef.findById(4);
		System.out.println(a.getName());
		
		
		assertTrue(a.getName().equals("Akashii"));
		
	}
@After
public void tearDown()
{
	System.out.println("cleaning up Dao object");
	daoRef=null;
}




	
	
	
}
