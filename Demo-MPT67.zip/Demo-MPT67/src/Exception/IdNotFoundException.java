package Exception;

public class IdNotFoundException extends Exception {

}
